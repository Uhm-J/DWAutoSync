# Dragon Wilds Auto-Sync v0.1.0 
## Website    
http://217.160.89.190:6900/    
(this should be the server URL too)    
## Quick Start Guide    
1. Run the DWAutoSync.exe application    
2. The application will start in your system tray (look for the icon in the bottom-right of your screen)    
3. Left-click the tray icon to open the main window    
4. Click the "Settings" button to configure the application    
## Configuration    
The first time you run the application, you'll need to configure it:    
1. Enter your information:    
   - **User Name**: Your username for identification on the server -- More like a nickname    
   - **API Key**: The authentication key provided by your server administrator    
   - **Server URL**: The URL of the Dragon Wilds sync server (e.g., https://dragonwilds.com/)    
   - **Save File Name**: The name of your Dragon Wilds save file (usually "DragonWilds.sav")    
2. Click "Save" to store your settings    
Your settings are stored at: `%USERPROFILE%\Documents\DragonWildsAutoSync\settings.json`    
## Usage    
Once configured, the application will:    
- Run in your system tray    
- Monitor when Dragon Wilds game is running    
- Automatically upload your save file when the game closes    
### Main Window    
- **Settings**: Configure your connection settings    
- **Ping Server**: Test the connection to the server    
- **Force Upload Save**: Manually upload your current save file    
- **Download Latest Save**: Download the latest save file from the server    
### System Tray    
- **Left-click**: Show/hide the main window    
- **Right-click**: Opens a menu with options to show the window or quit    
## Running at Startup    
To have the application start when Windows boots:    
1. Create a shortcut to DWAutoSync.exe    
2. Press `Win+R` and type `shell:startup`    
3. Copy the shortcut to the startup folder    
## Troubleshooting    
- **Cannot connect to server**: Verify your server URL and API key in settings    
- **Save file not found**: Check that the save file name is correct    
- **Game not detected**: Ensure you're running the correct version of Dragon Wilds     
